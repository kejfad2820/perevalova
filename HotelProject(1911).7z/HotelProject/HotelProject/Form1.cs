﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;

namespace HotelProject
{
    public partial class Form1 : Form
    {
        static string relativePath = @"..\\..\\Hotel.mdf";
        string connectionString = $@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog =Hotel.mdf;AttachDBFilename={Path.Combine(AppDomain.CurrentDomain.BaseDirectory, relativePath)};Integrated Security=True;Connection Timeout=5";

        public Form1()
        {
            InitializeComponent();
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                Debug.WriteLine("Success");
            }catch(Exception ex)
            {
                Debug.Write(ex.Message);
            }
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttonAuth_Click(object sender, EventArgs e)
        {
            if(textLogin.Text == "admin")
            {
                if(textPassword.Text == "admin")
                {
                    Form2 f2 = new Form2();
                    this.Hide();
                    f2.ShowDialog();
                    this.Close();
                }
                else
                {
                    Console.WriteLine("Неправильный логин или пароль");
                }
            }
            else
            {
                Console.WriteLine("Неправильный логин или пароль");
            }
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
