﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace PiskaBobraFormsApp1
{ 
    public partial class Form1 : Form
    {
        private string returnedData;


        public Form1()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        // Владислав - Контрольная работа (in Progress).
        private void button3_Click(object sender, EventArgs e)
        {
            Form4 controlwork = new Form4();
            this.Hide();
            if (controlwork.ShowDialog() == DialogResult.OK)
            {
                this.returnedData = controlwork.ReturnedData;
                this.Show();

                MessageBox.Show(returnedData, "Результат контрольная работа", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                this.Show();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 theory = new Form2();
            theory.Closed += (s, args) => this.Close();
            theory.Show();

            // 1274; 725

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 reference = new Form6();
            reference.Closed += (s, args) => this.Close();
            reference.Show();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form5 help = new Form5();
            help.Closed += (s, args) => this.Close();
            help.Show();
        }
    }


}
