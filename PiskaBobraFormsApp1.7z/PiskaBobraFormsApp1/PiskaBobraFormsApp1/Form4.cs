﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PiskaBobraFormsApp1
{
    public partial class Form4 : Form
    {
        public int round = 0;

        public Form4()
        {
            InitializeComponent();
            pictureBox1.Image = Image.FromFile("Теория1.jpg");
            buttonBack.Enabled = false;
        }

        void Listing_Pictures(int round)
        {
            switch (round) 
            {
                case 0:
                    buttonBack.Enabled = false;
                    buttonNext.Enabled = true;
                    pictureBox1.Image = null;
                    pictureBox1.Image = Image.FromFile("Теория1.jpg");
                    break;
                case 1:
                    buttonBack.Enabled = true;
                    buttonNext.Enabled = true;
                    pictureBox1.Image = null;
                    pictureBox1.Image = Image.FromFile("Теория2.jpg");
                    break;
                case 2:
                    buttonBack.Enabled = true;
                    buttonNext.Enabled = true;
                    pictureBox1.Image = null;
                    pictureBox1.Image = Image.FromFile("Теория3.jpg");
                    break;
                case 3:
                    buttonBack.Enabled = true;
                    buttonNext.Enabled = true;
                    pictureBox1.Image = null;
                    pictureBox1.Image = Image.FromFile("Теория4.jpg");
                    break;
                case 4:
                    buttonBack.Enabled = true;
                    buttonNext.Enabled = false;
                    pictureBox1.Image = null;
                    pictureBox1.Image = Image.FromFile("Теория5.jpg");
                    break;

            }
        }

        private void buttonTrain_Click(object sender, EventArgs e)
        {

        }

        private void buttonExam_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 exam = new Form2();
            exam.Closed += (s, args) => this.Close();
            exam.Show();
        }

        private void buttonHelp_Click(object sender, EventArgs e)
        {

        }

        private void buttonRef_Click(object sender, EventArgs e)
        {

        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            Listing_Pictures(round -= 1);
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void buttonNext_Click(object sender, EventArgs e)
        {
            Listing_Pictures(round += 1);
        }
    }
}
