﻿namespace PiskaBobraFormsApp1
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonHelp = new System.Windows.Forms.Button();
            this.buttonRef = new System.Windows.Forms.Button();
            this.buttonExam = new System.Windows.Forms.Button();
            this.buttonTrain = new System.Windows.Forms.Button();
            this.buttonTheory = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.buttonBack = new System.Windows.Forms.Button();
            this.buttonNext = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonHelp
            // 
            this.buttonHelp.BackColor = System.Drawing.SystemColors.Control;
            this.buttonHelp.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonHelp.FlatAppearance.BorderSize = 100;
            this.buttonHelp.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonHelp.Location = new System.Drawing.Point(574, 3);
            this.buttonHelp.Name = "buttonHelp";
            this.buttonHelp.Size = new System.Drawing.Size(119, 29);
            this.buttonHelp.TabIndex = 10;
            this.buttonHelp.Text = "Помощь";
            this.buttonHelp.UseVisualStyleBackColor = false;
            this.buttonHelp.Click += new System.EventHandler(this.buttonHelp_Click);
            // 
            // buttonRef
            // 
            this.buttonRef.BackColor = System.Drawing.SystemColors.Control;
            this.buttonRef.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonRef.FlatAppearance.BorderSize = 100;
            this.buttonRef.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonRef.Location = new System.Drawing.Point(691, 3);
            this.buttonRef.Name = "buttonRef";
            this.buttonRef.Size = new System.Drawing.Size(116, 29);
            this.buttonRef.TabIndex = 9;
            this.buttonRef.Text = "Справка";
            this.buttonRef.UseVisualStyleBackColor = false;
            this.buttonRef.Click += new System.EventHandler(this.buttonRef_Click);
            // 
            // buttonExam
            // 
            this.buttonExam.BackColor = System.Drawing.SystemColors.Control;
            this.buttonExam.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonExam.FlatAppearance.BorderSize = 100;
            this.buttonExam.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonExam.Location = new System.Drawing.Point(316, 3);
            this.buttonExam.Name = "buttonExam";
            this.buttonExam.Size = new System.Drawing.Size(260, 29);
            this.buttonExam.TabIndex = 8;
            this.buttonExam.Text = "Режим контрольной работы";
            this.buttonExam.UseVisualStyleBackColor = false;
            this.buttonExam.Click += new System.EventHandler(this.buttonExam_Click);
            // 
            // buttonTrain
            // 
            this.buttonTrain.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTrain.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonTrain.FlatAppearance.BorderSize = 100;
            this.buttonTrain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonTrain.Location = new System.Drawing.Point(137, 3);
            this.buttonTrain.Name = "buttonTrain";
            this.buttonTrain.Size = new System.Drawing.Size(180, 29);
            this.buttonTrain.TabIndex = 7;
            this.buttonTrain.Text = "Режим тренировки";
            this.buttonTrain.UseVisualStyleBackColor = false;
            this.buttonTrain.Click += new System.EventHandler(this.buttonTrain_Click);
            // 
            // buttonTheory
            // 
            this.buttonTheory.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTheory.Enabled = false;
            this.buttonTheory.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonTheory.FlatAppearance.BorderSize = 100;
            this.buttonTheory.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonTheory.Location = new System.Drawing.Point(-1, 3);
            this.buttonTheory.Name = "buttonTheory";
            this.buttonTheory.Size = new System.Drawing.Size(138, 29);
            this.buttonTheory.TabIndex = 6;
            this.buttonTheory.Text = "Режим теории";
            this.buttonTheory.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(151, 74);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(710, 430);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // buttonBack
            // 
            this.buttonBack.Location = new System.Drawing.Point(316, 535);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(75, 23);
            this.buttonBack.TabIndex = 12;
            this.buttonBack.Text = "<";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // buttonNext
            // 
            this.buttonNext.Location = new System.Drawing.Point(574, 535);
            this.buttonNext.Name = "buttonNext";
            this.buttonNext.Size = new System.Drawing.Size(75, 23);
            this.buttonNext.TabIndex = 13;
            this.buttonNext.Text = ">";
            this.buttonNext.UseVisualStyleBackColor = true;
            this.buttonNext.Click += new System.EventHandler(this.buttonNext_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1083, 686);
            this.Controls.Add(this.buttonNext);
            this.Controls.Add(this.buttonBack);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.buttonHelp);
            this.Controls.Add(this.buttonRef);
            this.Controls.Add(this.buttonExam);
            this.Controls.Add(this.buttonTrain);
            this.Controls.Add(this.buttonTheory);
            this.Name = "Form4";
            this.Text = "Режим теории";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonHelp;
        private System.Windows.Forms.Button buttonRef;
        private System.Windows.Forms.Button buttonExam;
        private System.Windows.Forms.Button buttonTrain;
        private System.Windows.Forms.Button buttonTheory;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.Button buttonNext;
    }
}