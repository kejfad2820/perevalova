import sys
sys.path.insert(1, 'C:/Users/22_ИС-391к/Desktop/teachers/teachers/')

from model.admin_crud import AdminModel

class AdminPresenter:

    def __init__(self,view):
        self.admin_crud = AdminModel("C:/Users/22_ИС-391к/Desktop/teachers/teachers/model/student_management.db")
        self.view = view

    def get_students(self):
        return self.admin_crud.get_students()

    def get_teachers(self):
        return self.admin_crud.get_teachers()

    def get_users(self):
        return self.admin_crud.get_users()

    def get_courses(self):
        return self.admin_crud.get_courses()

    def get_enrollments(self):
        return self.admin_crud.get_enrollments()

    def remove_user(self):
        return self.admin_crud.remove_user(user_id)