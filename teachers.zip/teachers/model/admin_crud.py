
import sqlite3

class AdminModel:
    def __init__(self, db_path="model/student_management.db"):
        self.db_path = db_path


    def get_students(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM students")
        result = cursor.fetchall()
        conn.close()
        return result

    def get_teachers(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM teachers")
        result = cursor.fetchall()
        conn.close()
        return result

    def get_users(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users")
        result = cursor.fetchall()
        conn.close()
        return result

    def get_courses(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM courses")
        result = cursor.fetchall()
        conn.close()
        return result


    def get_enrollments(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM enrollments")
        result = cursor.fetchall()
        conn.close()
        return result

    def remove_user(self, user_id):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("DELETE user_id FROM users")
        conn.commit()
        conn.close()