import sys
sys.path.insert(1, 'C:/Users/22_ИС-391к/Desktop/teachers/')
from view.login_view import login_view

app = login_view()
app.mainloop()