
import sqlite3

class AdminModel:
    def __init__(self, db_path="C:/Users/22_ИС-391к/Desktop/teachers/teachers/model/student_management.db"):
        self.db_path = db_path

    def get_students(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM students")
        result = cursor.fetchall()
        conn.close()
        return result

    def get_teachers(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM teachers")
        result = cursor.fetchall()
        conn.close()
        return result

    def get_users(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users")
        result = cursor.fetchall()
        conn.close()
        return result

    def get_courses(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM courses")
        result = cursor.fetchall()
        conn.close()
        return result

    def get_enrollments(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM enrollments")
        result = cursor.fetchall()
        conn.close()
        return result

    def remove_user(self, username):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM users WHERE user_id = ?", (username,))
        conn.commit()
        conn.close()

    def create_user(self, username, password, role):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO users (username ,password ,role) VALUES (?,?,?)", (username, password, role,))
        conn.commit()
        conn.close()

    def update_cell(self, table, entry_id, column, new_value):
        connection = sqlite3.connect(self.db_path)
        cursor = connection.cursor()
        cursor.execute(f"UPDATE {table} SET {column} = ? WHERE user_id = ?", (new_value, entry_id))
        connection.commit()
        connection.close()