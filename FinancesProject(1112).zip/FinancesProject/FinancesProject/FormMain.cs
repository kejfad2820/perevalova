﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace FinancesProject
{
    public partial class FormMain : Form
    {
        static string relativePath = @"..\\..\\UsersDB.mdf";
        string connectionString = $@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=UsersDB.mdf;AttachDBFilename={Path.Combine(AppDomain.CurrentDomain.BaseDirectory, relativePath)};Integrated Security=True;Connection Timeout=5";

        public void OpenWindow(Panel panel)
        {
            panelWallets.Visible = false;
            panelWallets.Enabled = false;
            panelStat.Visible = false;
            panelStat.Enabled = false;
            panelMain.Visible = false;
            panelMain.Enabled = false;
            panelProfile.Enabled = false;
            panelProfile.Visible = false;
            panel.Visible = true;
            panel.Enabled = true;
        }

        public FormMain()
        {
            InitializeComponent();
            OpenWindow(panelMain);
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    Debug.WriteLine("Success connection");
                }
                catch (SqlException ex)
                {
                    Debug.WriteLine(ex.Message);
                }
            }
        }

        private void buttonProfile_Click(object sender, EventArgs e)
        {
            OpenWindow(panelProfile);
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonMain_Click(object sender, EventArgs e)
        {
            OpenWindow(panelMain);
        }

        private void buttonExpenses_Click(object sender, EventArgs e)
        {
            
        }

        private void buttonIncomes_Click(object sender, EventArgs e)
        {
            
        }

        private void buttonStat_Click(object sender, EventArgs e)
        {
            OpenWindow(panelStat);
        }

        private void buttonWallets_Click(object sender, EventArgs e)
        {
            OpenWindow(panelWallets);
        }

        private void panelMain_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelExpenses_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Expense1_Enter(object sender, EventArgs e)
        {

        }

        private void buttonAddExpense_Click(object sender, EventArgs e)
        {

        }

        private void panelIncomes_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Income1_Enter(object sender, EventArgs e)
        {

        }

        private void buttonAddIncome_Click(object sender, EventArgs e)
        {

        }

        private void panelWallets_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Wallet1_Enter(object sender, EventArgs e)
        {

        }

        private void panelStat_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void buttonReg_Click(object sender, EventArgs e)
        {

        }

        private void buttonAuthPanel_Click(object sender, EventArgs e)
        {
            
        }

        private void panelRegistration_Paint(object sender, PaintEventArgs e)
        {

        }

        private void buttonRegPanel_Click(object sender, EventArgs e)
        {
            
        }

        private void textPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonAuth_Click(object sender, EventArgs e)
        {
            
        }

        private void buttonCreateExspense_Click(object sender, EventArgs e)
        {
            
        }

        private void buttonCreateIncome_Click(object sender, EventArgs e)
        {

        }
    }
}
