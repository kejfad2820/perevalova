﻿namespace FinancesProject
{
    partial class FormMain
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonStat = new System.Windows.Forms.Button();
            this.buttonWallets = new System.Windows.Forms.Button();
            this.buttonProfile = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonMain = new System.Windows.Forms.Button();
            this.panelMain = new System.Windows.Forms.Panel();
            this.Writes = new System.Windows.Forms.GroupBox();
            this.labelDate = new System.Windows.Forms.Label();
            this.labelWallet = new System.Windows.Forms.Label();
            this.labelType = new System.Windows.Forms.Label();
            this.labelCategory = new System.Windows.Forms.Label();
            this.labelAmount = new System.Windows.Forms.Label();
            this.buttonCreateIncome = new System.Windows.Forms.Button();
            this.buttonCreateExspense = new System.Windows.Forms.Button();
            this.labelMain = new System.Windows.Forms.Label();
            this.panelStat = new System.Windows.Forms.Panel();
            this.labelStat = new System.Windows.Forms.Label();
            this.panelWallets = new System.Windows.Forms.Panel();
            this.Wallet1 = new System.Windows.Forms.GroupBox();
            this.labelWalletAmount = new System.Windows.Forms.Label();
            this.labelWallets = new System.Windows.Forms.Label();
            this.panelProfile = new System.Windows.Forms.Panel();
            this.labelProfileName = new System.Windows.Forms.Label();
            this.labelProfile = new System.Windows.Forms.Label();
            this.panelMain.SuspendLayout();
            this.Writes.SuspendLayout();
            this.panelStat.SuspendLayout();
            this.panelWallets.SuspendLayout();
            this.Wallet1.SuspendLayout();
            this.panelProfile.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonStat
            // 
            this.buttonStat.Location = new System.Drawing.Point(15, 200);
            this.buttonStat.Name = "buttonStat";
            this.buttonStat.Size = new System.Drawing.Size(100, 55);
            this.buttonStat.TabIndex = 2;
            this.buttonStat.Text = "Статистика";
            this.buttonStat.UseVisualStyleBackColor = true;
            this.buttonStat.Click += new System.EventHandler(this.buttonStat_Click);
            // 
            // buttonWallets
            // 
            this.buttonWallets.Location = new System.Drawing.Point(15, 257);
            this.buttonWallets.Name = "buttonWallets";
            this.buttonWallets.Size = new System.Drawing.Size(100, 55);
            this.buttonWallets.TabIndex = 3;
            this.buttonWallets.Text = "Кошельки";
            this.buttonWallets.UseVisualStyleBackColor = true;
            this.buttonWallets.Click += new System.EventHandler(this.buttonWallets_Click);
            // 
            // buttonProfile
            // 
            this.buttonProfile.Location = new System.Drawing.Point(713, 12);
            this.buttonProfile.Name = "buttonProfile";
            this.buttonProfile.Size = new System.Drawing.Size(75, 23);
            this.buttonProfile.TabIndex = 4;
            this.buttonProfile.Text = "Профиль";
            this.buttonProfile.UseVisualStyleBackColor = true;
            this.buttonProfile.Click += new System.EventHandler(this.buttonProfile_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(713, 415);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(75, 23);
            this.buttonExit.TabIndex = 5;
            this.buttonExit.Text = "Выйти";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonMain
            // 
            this.buttonMain.Location = new System.Drawing.Point(15, 143);
            this.buttonMain.Name = "buttonMain";
            this.buttonMain.Size = new System.Drawing.Size(100, 55);
            this.buttonMain.TabIndex = 6;
            this.buttonMain.Text = "Главная";
            this.buttonMain.UseVisualStyleBackColor = true;
            this.buttonMain.Click += new System.EventHandler(this.buttonMain_Click);
            // 
            // panelMain
            // 
            this.panelMain.Controls.Add(this.Writes);
            this.panelMain.Controls.Add(this.buttonCreateIncome);
            this.panelMain.Controls.Add(this.buttonCreateExspense);
            this.panelMain.Controls.Add(this.labelMain);
            this.panelMain.Enabled = false;
            this.panelMain.Location = new System.Drawing.Point(118, 41);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(605, 368);
            this.panelMain.TabIndex = 7;
            this.panelMain.Visible = false;
            this.panelMain.Paint += new System.Windows.Forms.PaintEventHandler(this.panelMain_Paint);
            // 
            // Writes
            // 
            this.Writes.Controls.Add(this.labelDate);
            this.Writes.Controls.Add(this.labelWallet);
            this.Writes.Controls.Add(this.labelType);
            this.Writes.Controls.Add(this.labelCategory);
            this.Writes.Controls.Add(this.labelAmount);
            this.Writes.Location = new System.Drawing.Point(165, 58);
            this.Writes.Name = "Writes";
            this.Writes.Size = new System.Drawing.Size(259, 100);
            this.Writes.TabIndex = 3;
            this.Writes.TabStop = false;
            this.Writes.Text = "Запись 1";
            // 
            // labelDate
            // 
            this.labelDate.AutoSize = true;
            this.labelDate.Location = new System.Drawing.Point(179, 70);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(33, 13);
            this.labelDate.TabIndex = 4;
            this.labelDate.Text = "Дата";
            // 
            // labelWallet
            // 
            this.labelWallet.AutoSize = true;
            this.labelWallet.Location = new System.Drawing.Point(179, 45);
            this.labelWallet.Name = "labelWallet";
            this.labelWallet.Size = new System.Drawing.Size(52, 13);
            this.labelWallet.TabIndex = 3;
            this.labelWallet.Text = "Кошелек";
            // 
            // labelType
            // 
            this.labelType.AutoSize = true;
            this.labelType.Location = new System.Drawing.Point(23, 70);
            this.labelType.Name = "labelType";
            this.labelType.Size = new System.Drawing.Size(26, 13);
            this.labelType.TabIndex = 2;
            this.labelType.Text = "Тип";
            // 
            // labelCategory
            // 
            this.labelCategory.AutoSize = true;
            this.labelCategory.Location = new System.Drawing.Point(23, 45);
            this.labelCategory.Name = "labelCategory";
            this.labelCategory.Size = new System.Drawing.Size(60, 13);
            this.labelCategory.TabIndex = 1;
            this.labelCategory.Text = "Категория";
            // 
            // labelAmount
            // 
            this.labelAmount.AutoSize = true;
            this.labelAmount.Location = new System.Drawing.Point(23, 20);
            this.labelAmount.Name = "labelAmount";
            this.labelAmount.Size = new System.Drawing.Size(41, 13);
            this.labelAmount.TabIndex = 0;
            this.labelAmount.Text = "Сумма";
            // 
            // buttonCreateIncome
            // 
            this.buttonCreateIncome.Location = new System.Drawing.Point(298, 317);
            this.buttonCreateIncome.Name = "buttonCreateIncome";
            this.buttonCreateIncome.Size = new System.Drawing.Size(104, 48);
            this.buttonCreateIncome.TabIndex = 2;
            this.buttonCreateIncome.Text = "Добавить доход";
            this.buttonCreateIncome.UseVisualStyleBackColor = true;
            this.buttonCreateIncome.Click += new System.EventHandler(this.buttonCreateIncome_Click);
            // 
            // buttonCreateExspense
            // 
            this.buttonCreateExspense.Location = new System.Drawing.Point(188, 317);
            this.buttonCreateExspense.Name = "buttonCreateExspense";
            this.buttonCreateExspense.Size = new System.Drawing.Size(104, 48);
            this.buttonCreateExspense.TabIndex = 1;
            this.buttonCreateExspense.Text = "Добавить трату";
            this.buttonCreateExspense.UseVisualStyleBackColor = true;
            this.buttonCreateExspense.Click += new System.EventHandler(this.buttonCreateExspense_Click);
            // 
            // labelMain
            // 
            this.labelMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelMain.Location = new System.Drawing.Point(217, 11);
            this.labelMain.Name = "labelMain";
            this.labelMain.Size = new System.Drawing.Size(153, 41);
            this.labelMain.TabIndex = 0;
            this.labelMain.Text = "Главная";
            // 
            // panelStat
            // 
            this.panelStat.Controls.Add(this.labelStat);
            this.panelStat.Enabled = false;
            this.panelStat.Location = new System.Drawing.Point(118, 41);
            this.panelStat.Name = "panelStat";
            this.panelStat.Size = new System.Drawing.Size(605, 368);
            this.panelStat.TabIndex = 10;
            this.panelStat.Visible = false;
            this.panelStat.Paint += new System.Windows.Forms.PaintEventHandler(this.panelStat_Paint);
            // 
            // labelStat
            // 
            this.labelStat.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelStat.Location = new System.Drawing.Point(195, 11);
            this.labelStat.Name = "labelStat";
            this.labelStat.Size = new System.Drawing.Size(207, 41);
            this.labelStat.TabIndex = 0;
            this.labelStat.Text = "Статистика";
            // 
            // panelWallets
            // 
            this.panelWallets.Controls.Add(this.Wallet1);
            this.panelWallets.Controls.Add(this.labelWallets);
            this.panelWallets.Enabled = false;
            this.panelWallets.Location = new System.Drawing.Point(118, 41);
            this.panelWallets.Name = "panelWallets";
            this.panelWallets.Size = new System.Drawing.Size(605, 368);
            this.panelWallets.TabIndex = 12;
            this.panelWallets.Visible = false;
            this.panelWallets.Paint += new System.Windows.Forms.PaintEventHandler(this.panelWallets_Paint);
            // 
            // Wallet1
            // 
            this.Wallet1.Controls.Add(this.labelWalletAmount);
            this.Wallet1.Location = new System.Drawing.Point(29, 58);
            this.Wallet1.Name = "Wallet1";
            this.Wallet1.Size = new System.Drawing.Size(200, 100);
            this.Wallet1.TabIndex = 1;
            this.Wallet1.TabStop = false;
            this.Wallet1.Text = "Кошелек 1";
            this.Wallet1.Enter += new System.EventHandler(this.Wallet1_Enter);
            // 
            // labelWalletAmount
            // 
            this.labelWalletAmount.AutoSize = true;
            this.labelWalletAmount.Location = new System.Drawing.Point(6, 26);
            this.labelWalletAmount.Name = "labelWalletAmount";
            this.labelWalletAmount.Size = new System.Drawing.Size(44, 13);
            this.labelWalletAmount.TabIndex = 0;
            this.labelWalletAmount.Text = "Баланс";
            // 
            // labelWallets
            // 
            this.labelWallets.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelWallets.Location = new System.Drawing.Point(215, 11);
            this.labelWallets.Name = "labelWallets";
            this.labelWallets.Size = new System.Drawing.Size(181, 41);
            this.labelWallets.TabIndex = 0;
            this.labelWallets.Text = "Кошельки";
            // 
            // panelProfile
            // 
            this.panelProfile.Controls.Add(this.labelProfileName);
            this.panelProfile.Controls.Add(this.labelProfile);
            this.panelProfile.Enabled = false;
            this.panelProfile.Location = new System.Drawing.Point(118, 41);
            this.panelProfile.Name = "panelProfile";
            this.panelProfile.Size = new System.Drawing.Size(605, 368);
            this.panelProfile.TabIndex = 15;
            this.panelProfile.Visible = false;
            // 
            // labelProfileName
            // 
            this.labelProfileName.AutoSize = true;
            this.labelProfileName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelProfileName.Location = new System.Drawing.Point(251, 66);
            this.labelProfileName.Name = "labelProfileName";
            this.labelProfileName.Size = new System.Drawing.Size(75, 25);
            this.labelProfileName.TabIndex = 1;
            this.labelProfileName.Text = "label10";
            // 
            // labelProfile
            // 
            this.labelProfile.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelProfile.Location = new System.Drawing.Point(178, 11);
            this.labelProfile.Name = "labelProfile";
            this.labelProfile.Size = new System.Drawing.Size(248, 41);
            this.labelProfile.TabIndex = 0;
            this.labelProfile.Text = "Ваш профиль";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.panelProfile);
            this.Controls.Add(this.panelWallets);
            this.Controls.Add(this.panelStat);
            this.Controls.Add(this.buttonMain);
            this.Controls.Add(this.buttonStat);
            this.Controls.Add(this.buttonWallets);
            this.Controls.Add(this.buttonProfile);
            this.Controls.Add(this.buttonExit);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Учет финансов";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelMain.ResumeLayout(false);
            this.Writes.ResumeLayout(false);
            this.Writes.PerformLayout();
            this.panelStat.ResumeLayout(false);
            this.panelWallets.ResumeLayout(false);
            this.Wallet1.ResumeLayout(false);
            this.Wallet1.PerformLayout();
            this.panelProfile.ResumeLayout(false);
            this.panelProfile.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button buttonStat;
        private System.Windows.Forms.Button buttonWallets;
        private System.Windows.Forms.Button buttonProfile;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonMain;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Label labelMain;
        private System.Windows.Forms.Button buttonCreateExspense;
        private System.Windows.Forms.Button buttonCreateIncome;
        private System.Windows.Forms.GroupBox Writes;
        private System.Windows.Forms.Label labelWallet;
        private System.Windows.Forms.Label labelType;
        private System.Windows.Forms.Label labelCategory;
        private System.Windows.Forms.Label labelAmount;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.Panel panelStat;
        private System.Windows.Forms.Label labelStat;
        private System.Windows.Forms.Panel panelWallets;
        private System.Windows.Forms.GroupBox Wallet1;
        private System.Windows.Forms.Label labelWalletAmount;
        private System.Windows.Forms.Label labelWallets;
        private System.Windows.Forms.Panel panelProfile;
        private System.Windows.Forms.Label labelProfile;
        private System.Windows.Forms.Label labelProfileName;
    }
}

