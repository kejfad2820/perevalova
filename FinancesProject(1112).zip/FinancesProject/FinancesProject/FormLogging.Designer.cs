﻿namespace FinancesProject
{
    partial class FormLogging
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelAuthorization = new System.Windows.Forms.Panel();
            this.labelPassAuth = new System.Windows.Forms.Label();
            this.labelLoginAuth = new System.Windows.Forms.Label();
            this.buttonAuth = new System.Windows.Forms.Button();
            this.buttonRegPanel = new System.Windows.Forms.Button();
            this.textPassword = new System.Windows.Forms.TextBox();
            this.textLogin = new System.Windows.Forms.TextBox();
            this.labelAuthorization = new System.Windows.Forms.Label();
            this.panelRegistration = new System.Windows.Forms.Panel();
            this.labelPassReg = new System.Windows.Forms.Label();
            this.labelLoginReg = new System.Windows.Forms.Label();
            this.labelMailReg = new System.Windows.Forms.Label();
            this.textPasswordRegRep = new System.Windows.Forms.TextBox();
            this.buttonAuthPanel = new System.Windows.Forms.Button();
            this.buttonReg = new System.Windows.Forms.Button();
            this.textPasswordReg = new System.Windows.Forms.TextBox();
            this.textLoginReg = new System.Windows.Forms.TextBox();
            this.labelReg = new System.Windows.Forms.Label();
            this.panelAuthorization.SuspendLayout();
            this.panelRegistration.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelAuthorization
            // 
            this.panelAuthorization.Controls.Add(this.labelPassAuth);
            this.panelAuthorization.Controls.Add(this.labelLoginAuth);
            this.panelAuthorization.Controls.Add(this.buttonAuth);
            this.panelAuthorization.Controls.Add(this.buttonRegPanel);
            this.panelAuthorization.Controls.Add(this.textPassword);
            this.panelAuthorization.Controls.Add(this.textLogin);
            this.panelAuthorization.Controls.Add(this.labelAuthorization);
            this.panelAuthorization.Enabled = false;
            this.panelAuthorization.Location = new System.Drawing.Point(13, 12);
            this.panelAuthorization.Name = "panelAuthorization";
            this.panelAuthorization.Size = new System.Drawing.Size(775, 426);
            this.panelAuthorization.TabIndex = 14;
            this.panelAuthorization.Visible = false;
            // 
            // labelPassAuth
            // 
            this.labelPassAuth.AutoSize = true;
            this.labelPassAuth.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.labelPassAuth.Location = new System.Drawing.Point(205, 175);
            this.labelPassAuth.Name = "labelPassAuth";
            this.labelPassAuth.Size = new System.Drawing.Size(80, 25);
            this.labelPassAuth.TabIndex = 8;
            this.labelPassAuth.Text = "Пароль";
            // 
            // labelLoginAuth
            // 
            this.labelLoginAuth.AutoSize = true;
            this.labelLoginAuth.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.labelLoginAuth.Location = new System.Drawing.Point(217, 108);
            this.labelLoginAuth.Name = "labelLoginAuth";
            this.labelLoginAuth.Size = new System.Drawing.Size(68, 25);
            this.labelLoginAuth.TabIndex = 7;
            this.labelLoginAuth.Text = "Логин";
            // 
            // buttonAuth
            // 
            this.buttonAuth.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAuth.Location = new System.Drawing.Point(346, 228);
            this.buttonAuth.Name = "buttonAuth";
            this.buttonAuth.Size = new System.Drawing.Size(95, 44);
            this.buttonAuth.TabIndex = 3;
            this.buttonAuth.Text = "Войти";
            this.buttonAuth.UseVisualStyleBackColor = true;
            this.buttonAuth.Click += new System.EventHandler(this.buttonAuth_Click);
            // 
            // buttonRegPanel
            // 
            this.buttonRegPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonRegPanel.Location = new System.Drawing.Point(301, 309);
            this.buttonRegPanel.Name = "buttonRegPanel";
            this.buttonRegPanel.Size = new System.Drawing.Size(190, 61);
            this.buttonRegPanel.TabIndex = 4;
            this.buttonRegPanel.Text = "Нет аккаунта? Зарегистрироваться";
            this.buttonRegPanel.UseVisualStyleBackColor = true;
            this.buttonRegPanel.Click += new System.EventHandler(this.buttonRegPanel_Click);
            // 
            // textPassword
            // 
            this.textPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textPassword.Location = new System.Drawing.Point(286, 173);
            this.textPassword.Name = "textPassword";
            this.textPassword.Size = new System.Drawing.Size(205, 27);
            this.textPassword.TabIndex = 2;
            this.textPassword.UseSystemPasswordChar = true;
            // 
            // textLogin
            // 
            this.textLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textLogin.Location = new System.Drawing.Point(286, 106);
            this.textLogin.Name = "textLogin";
            this.textLogin.Size = new System.Drawing.Size(205, 27);
            this.textLogin.TabIndex = 1;
            this.textLogin.TextChanged += new System.EventHandler(this.textLogin_TextChanged);
            // 
            // labelAuthorization
            // 
            this.labelAuthorization.AutoSize = true;
            this.labelAuthorization.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelAuthorization.Location = new System.Drawing.Point(320, 29);
            this.labelAuthorization.Name = "labelAuthorization";
            this.labelAuthorization.Size = new System.Drawing.Size(135, 25);
            this.labelAuthorization.TabIndex = 0;
            this.labelAuthorization.Text = "Авторизация";
            // 
            // panelRegistration
            // 
            this.panelRegistration.Controls.Add(this.labelPassReg);
            this.panelRegistration.Controls.Add(this.labelLoginReg);
            this.panelRegistration.Controls.Add(this.labelMailReg);
            this.panelRegistration.Controls.Add(this.textPasswordRegRep);
            this.panelRegistration.Controls.Add(this.buttonAuthPanel);
            this.panelRegistration.Controls.Add(this.buttonReg);
            this.panelRegistration.Controls.Add(this.textPasswordReg);
            this.panelRegistration.Controls.Add(this.textLoginReg);
            this.panelRegistration.Controls.Add(this.labelReg);
            this.panelRegistration.Location = new System.Drawing.Point(13, 12);
            this.panelRegistration.Name = "panelRegistration";
            this.panelRegistration.Size = new System.Drawing.Size(775, 426);
            this.panelRegistration.TabIndex = 15;
            // 
            // labelPassReg
            // 
            this.labelPassReg.AutoSize = true;
            this.labelPassReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.labelPassReg.Location = new System.Drawing.Point(203, 195);
            this.labelPassReg.Name = "labelPassReg";
            this.labelPassReg.Size = new System.Drawing.Size(80, 25);
            this.labelPassReg.TabIndex = 8;
            this.labelPassReg.Text = "Пароль";
            // 
            // labelLoginReg
            // 
            this.labelLoginReg.AutoSize = true;
            this.labelLoginReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.labelLoginReg.Location = new System.Drawing.Point(215, 150);
            this.labelLoginReg.Name = "labelLoginReg";
            this.labelLoginReg.Size = new System.Drawing.Size(68, 25);
            this.labelLoginReg.TabIndex = 7;
            this.labelLoginReg.Text = "Логин";
            // 
            // labelMailReg
            // 
            this.labelMailReg.AutoSize = true;
            this.labelMailReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.labelMailReg.Location = new System.Drawing.Point(180, 106);
            this.labelMailReg.Name = "labelMailReg";
            this.labelMailReg.Size = new System.Drawing.Size(103, 25);
            this.labelMailReg.TabIndex = 6;
            this.labelMailReg.Text = "Эл. почта";
            // 
            // textPasswordRegRep
            // 
            this.textPasswordRegRep.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textPasswordRegRep.Location = new System.Drawing.Point(285, 193);
            this.textPasswordRegRep.Name = "textPasswordRegRep";
            this.textPasswordRegRep.Size = new System.Drawing.Size(205, 27);
            this.textPasswordRegRep.TabIndex = 5;
            this.textPasswordRegRep.UseSystemPasswordChar = true;
            // 
            // buttonAuthPanel
            // 
            this.buttonAuthPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAuthPanel.Location = new System.Drawing.Point(294, 306);
            this.buttonAuthPanel.Name = "buttonAuthPanel";
            this.buttonAuthPanel.Size = new System.Drawing.Size(196, 49);
            this.buttonAuthPanel.TabIndex = 4;
            this.buttonAuthPanel.Text = "Авторизоваться";
            this.buttonAuthPanel.UseVisualStyleBackColor = true;
            this.buttonAuthPanel.Click += new System.EventHandler(this.buttonAuthPanel_Click);
            // 
            // buttonReg
            // 
            this.buttonReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonReg.Location = new System.Drawing.Point(293, 256);
            this.buttonReg.Name = "buttonReg";
            this.buttonReg.Size = new System.Drawing.Size(198, 44);
            this.buttonReg.TabIndex = 3;
            this.buttonReg.Text = "Зарегистрироваться";
            this.buttonReg.UseVisualStyleBackColor = true;
            // 
            // textPasswordReg
            // 
            this.textPasswordReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textPasswordReg.Location = new System.Drawing.Point(286, 148);
            this.textPasswordReg.Name = "textPasswordReg";
            this.textPasswordReg.Size = new System.Drawing.Size(205, 27);
            this.textPasswordReg.TabIndex = 2;
            this.textPasswordReg.UseSystemPasswordChar = true;
            // 
            // textLoginReg
            // 
            this.textLoginReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textLoginReg.Location = new System.Drawing.Point(286, 106);
            this.textLoginReg.Name = "textLoginReg";
            this.textLoginReg.Size = new System.Drawing.Size(205, 27);
            this.textLoginReg.TabIndex = 1;
            // 
            // labelReg
            // 
            this.labelReg.AutoSize = true;
            this.labelReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelReg.Location = new System.Drawing.Point(320, 29);
            this.labelReg.Name = "labelReg";
            this.labelReg.Size = new System.Drawing.Size(131, 25);
            this.labelReg.TabIndex = 0;
            this.labelReg.Text = "Регистрация";
            // 
            // FormLogging
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelAuthorization);
            this.Controls.Add(this.panelRegistration);
            this.Name = "FormLogging";
            this.Text = "Учет финансов";
            this.Load += new System.EventHandler(this.FormLogging_Load);
            this.panelAuthorization.ResumeLayout(false);
            this.panelAuthorization.PerformLayout();
            this.panelRegistration.ResumeLayout(false);
            this.panelRegistration.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelAuthorization;
        private System.Windows.Forms.Label labelPassAuth;
        private System.Windows.Forms.Label labelLoginAuth;
        private System.Windows.Forms.Button buttonAuth;
        private System.Windows.Forms.Button buttonRegPanel;
        private System.Windows.Forms.TextBox textPassword;
        private System.Windows.Forms.TextBox textLogin;
        private System.Windows.Forms.Label labelAuthorization;
        private System.Windows.Forms.Panel panelRegistration;
        private System.Windows.Forms.Label labelPassReg;
        private System.Windows.Forms.Label labelLoginReg;
        private System.Windows.Forms.Label labelMailReg;
        private System.Windows.Forms.TextBox textPasswordRegRep;
        private System.Windows.Forms.Button buttonAuthPanel;
        private System.Windows.Forms.Button buttonReg;
        private System.Windows.Forms.TextBox textPasswordReg;
        private System.Windows.Forms.TextBox textLoginReg;
        private System.Windows.Forms.Label labelReg;
    }
}