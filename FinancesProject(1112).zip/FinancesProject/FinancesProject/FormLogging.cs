﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinancesProject
{
    public partial class FormLogging : Form
    {
        public FormLogging()
        {
            InitializeComponent();
        }

        public void OpenPanel(Panel panel)
        {
            panelAuthorization.Enabled = false;
            panelAuthorization.Visible = false;
            panelRegistration.Enabled = false;
            panelRegistration.Visible = false;

            panel.Enabled = true;
            panel.Visible = true;
        }

        private void FormLogging_Load(object sender, EventArgs e)
        {
            OpenPanel(panelAuthorization);
        }

        private void buttonAuthPanel_Click(object sender, EventArgs e)
        {
            OpenPanel(panelAuthorization);
        }

        private void buttonRegPanel_Click(object sender, EventArgs e)
        {
            OpenPanel(panelRegistration);
        }

        private void buttonAuth_Click(object sender, EventArgs e)
        {
            if (textLogin.Text == "admin" && textPassword.Text == "admin")
            {
                FormMain f2 = new FormMain();
                this.Hide();
                f2.ShowDialog();
                this.Close();
            }
            
        }

        private void textLogin_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
