﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelProject
{
    public partial class Form2 : Form
    {
        static string relativePath = @"..\\..\\Hotel.mdf";
        string connectionString = $@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=Hotel.mdf;AttachDBFilename={Path.Combine(AppDomain.CurrentDomain.BaseDirectory, relativePath)};Integrated Security=True;Connection Timeout=5";


        public Form2()
        {
            InitializeComponent();

            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                Debug.WriteLine("Success");
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }

            CheckTablesOfDB();
        }

        public void CheckTablesOfDB()
        {
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "SELECT name FROM sys.Tables";
                SqlCommand check = new SqlCommand(sql, conn);
                SqlDataReader reader = check.ExecuteReader();
                while (reader.Read())
                {
                    comboBoxTables.Items.Add(reader["name"].ToString());

                }
                reader.Close();
                conn.Close();
                Debug.WriteLine("Success showing of tables");
            }catch(Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }
            
        }

        public void ShowTables(DataGridView dataGridView)
        {
            usersDataGridView.Visible = false;
            usersDataGridView.Enabled = false;
            categoriesDataGridView.Visible = false;
            categoriesDataGridView.Enabled = false;
            roomOccupancyDataGridView.Visible = false;
            roomOccupancyDataGridView.Enabled = false;
            roomsDataGridView.Visible = false;
            roomsDataGridView.Enabled = false;
            statusCleaningDataGridView.Visible = false;
            statusCleaningDataGridView.Enabled = false;
            statusRoomDataGridView.Visible = false;
            statusRoomDataGridView.Enabled = false;
            rolesDataGridView.Visible = false;
            rolesDataGridView.Enabled = false;

            dataGridView.Visible = true;
            dataGridView.Enabled = true;
        }

        public void ShowPanel(Panel panel)
        {
            panelUsers.Visible = false;
            panelUsers.Enabled = false;
            panelCategories.Visible = false;
            panelCategories.Enabled = false;

            panel.Visible = true;
            panel.Enabled = true;
        }

        public void EnterTables()
        {
            switch (comboBoxTables.Text)
            {
                case "Categories":
                    ShowTables(categoriesDataGridView);
                    ShowPanel(panelCategories);
                    break;
                case "Rooms":
                    ShowTables(roomsDataGridView);
                    //ShowPanel(panelRooms);
                    break;
                case "Roles":
                    ShowTables(rolesDataGridView);
                    //ShowPanel(panelRoles);
                    break;
                case "Users":
                    ShowTables(usersDataGridView);
                    ShowPanel(panelUsers);
                    ShowRoles();
                    break;
                case "StatusRoom":
                    ShowTables(statusRoomDataGridView);
                    //ShowPanel(panelStatusRoom);
                    break;
                case "StatusCleaning":
                    ShowTables(statusCleaningDataGridView);
                    //ShowPanel(panelStatusCleaning);
                    break;
                case "RoomOccupancy":
                    ShowTables(roomOccupancyDataGridView);
                    //ShowPanel(panelRoomOccupancy);
                    break;
                default:
                    break;
            }
        }

        public void ShowRoles()
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            string sql = "SELECT Role FROM Roles";

            SqlCommand show = new SqlCommand(sql, conn);

            SqlDataReader reader = show.ExecuteReader();

            try
            {
                while (reader.Read())
                {
                    comboBoxUserRoles.Items.Add(reader["Role"].ToString());
                }
                reader.Close();
                conn.Close();
                Debug.WriteLine("Success showing of roles");
            }catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }
        }

        public void CreateUser()
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            try
            {
                string name = textBoxUserName.Text;
                string login = textBoxUserLogin.Text;
                string pass = textBoxUserPass.Text;
                string role = comboBoxUserRoles.Text;

                string sql = "SELECT IDRole FROM Roles WHERE Role = @role";

                SqlCommand checkIdRole = new SqlCommand(sql, conn);

                checkIdRole.Parameters.AddWithValue("@role", role);


                int idRole = (int)checkIdRole.ExecuteScalar();

                string sqlcommand = "INSERT INTO Users(FullName, Login, Password, RoleID) VALUES(@name, @login, @pass, @idRole)";

                SqlCommand createUser = new SqlCommand(sqlcommand, conn);

                createUser.Parameters.AddWithValue("@name", @name);
                createUser.Parameters.AddWithValue("@login", @login);
                createUser.Parameters.AddWithValue("@pass", @pass);
                createUser.Parameters.AddWithValue("@idRole", @idRole);

                int rows = createUser.ExecuteNonQuery();
                //usersBindingSource.EndEdit();
                //usersDataGridView.EndEdit();
                
                hotelDataSet1.Users.GetChanges();
                hotelDataSet1.Users.BeginInit();
                hotelDataSet1.Users.EndInit();

                for (int i = 0; i < hotelDataSet1.Users.Rows.Count - 1; i++)
                {
                    break;
                }
                
            }
            catch(Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }
            conn.Close();


        }

        private void Form2_Load(object sender, EventArgs e)
        {
            this.categoriesTableAdapter.Fill(this.hotelDataSet1.Categories);
            this.roomsTableAdapter.Fill(this.hotelDataSet1.Rooms);
            this.rolesTableAdapter.Fill(this.hotelDataSet1.Roles);
            this.usersTableAdapter.Fill(this.hotelDataSet1.Users);
            this.statusRoomTableAdapter.Fill(this.hotelDataSet1.StatusRoom);
            this.statusCleaningTableAdapter.Fill(this.hotelDataSet1.StatusCleaning);
            this.roomOccupancyTableAdapter.Fill(this.hotelDataSet1.RoomOccupancy);
        }

        private void categoriesBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.categoriesBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.hotelDataSet1);
        }

        private void comboBoxTables_SelectedIndexChanged(object sender, EventArgs e)
        {
            EnterTables();
        }

        private void buttonUserAdd_Click(object sender, EventArgs e)
        {
            CreateUser();
        }
    }
}
